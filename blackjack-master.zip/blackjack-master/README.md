# Blackjack
Based on the JavaScript course by Clever Programmer (Qazi and his team).
This is purely educational. Since he was taching this, I believe that this has no copyright.
And you can copy the code too, totally allowed.
